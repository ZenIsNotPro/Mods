Callback.addCallback("ItemUse",function(coords,item,block){
let Ran=Math.round(Math.random()*2);
let coords=Player.getPosition();
if(item.id==318&&block.id==1)
  {
  item.count--;
  if(!item.count){item.id=0};
  Player.setCarriedItem(item.id,item.count,0);
  if(Ran==1){World.drop(coords.x,coords.y,coords.z,ItemID.flint_flake,1,0);};
  };
if(item.id==318&&block.id==4)
  {
  item.count--;
  if(!item.count){item.id=0};
  Player.setCarriedItem(item.id,item.count,0);
  if(Ran==1){World.drop(coords.x,coords.y,coords.z,ItemID.flint_flake,1,0);};
  };
if(item.id==318&&block.id==48)
  {
  item.count--;
  if(!item.count){item.id=0};
  Player.setCarriedItem(item.id,item.count,0);
  if(Ran==1){World.drop(coords.x,coords.y,coords.z,ItemID.flint_flake,1,0);};
  };
if(item.id==ItemID.flint_hatchet&&block.id==17)
  {
  World.drop(coords.x,coords.y,coords.z,ItemID.oak_bark,1,0);
  oakbark.play();
  };
if(item.id==ItemID.flint_axe&&block.id==17)
  {
  World.drop(coords.x,coords.y,coords.z,ItemID.oak_bark,1,0);
  oakbark.play();
  };
});
Callback.addCallback("DestroyBlock",function(coords,block,player){
let ran_pf=Math.round(Math.random()*2);
let ran_flint=Math.round(Math.random()*4);
let ran_s=Math.round(Math.random()*4);
if(block.id==12)
  {
  if(ran_flint==2)
    {World.drop(coords.x,coords.y,coords.z,318,1,0);}
  else
    {};
  }
else
  {};
if(block.id==2||block.id==3)
  {
  if(ran_pf==1)
    {World.drop(coords.x,coords.y,coords.z,ItemID.plant_fiber,3,0);}
  else
    {};
  }
else
  {};
if(block.id==31&&block.data==1)
  {
  if(ran_pf==1)
    {World.drop(coords.x,coords.y,coords.z,ItemID.plant_fiber,1,0);}
  else
    {};
  }
else
  {};
if(block.id==18)
  {
  if(ran_s==2)
    {World.drop(coords.x,coords.y,coords.z,280,1,0);}
  else
    {};
  }
else
  {};
});
Block.registerDropFunction(17,function(coords,blockID,blockData,level,enchant){
if(level>0)
  {return [[17,1,0]];}
else
  {return [];};
});
Block.registerDropFunction(1,function(coords,blockID,blockData,level,enchant){
if(level>0)
  {return [[ItemID.rock_stone,8,0]];}
else
  {return [];};
});
Block.registerDropFunction(14,function(coords,blockID,blockData,level,enchant){
if(level>3)
  {return [[ItemID.gold_ore_rock,9,0]];}
else
  {return [];};
});
Block.registerDropFunction(15,function(coords,blockID,blockData,level,enchant){
if(level>2)
  {return [[ItemID.iron_ore_rock,9,0]];}
else
  {return [];};
});