IDRegistry.genItemID("flint_hatchet");
IDRegistry.genItemID("flint_axe");
IDRegistry.genItemID("flint_hoe");
IDRegistry.genItemID("flint_shovel");
IDRegistry.genItemID("flint_pickaxe");
IDRegistry.genItemID("flint_hand_saw");
IDRegistry.genItemID("bone_pickaxe");
IDRegistry.genItemID("bone_sharp");
Item.createItem("flint_axe","Flint Axe\n§1PrimalCore§r",{name:"flint_axe",meta:0},{stack:1});
Item.createItem("flint_hoe","Flint Hoe\n§1PrimalCore§r",{name:"flint_hoe",meta:0},{stack:1});
Item.createItem("flint_hand_saw","Flint Hand Saw\n§1PrimalCore§r",{name:"flint_saw",meta:0},{stack:1});
Item.createItem("flint_shovel","Flint Shovel\n§1PrimalCore§r",{name:"flint_shovel",meta:0},{stack:1});
Item.createItem("flint_hatchet","Flint Hatchet\n§1PrimalCore§r",{name:"flint_hatchet",meta:0},{stack:1});
Item.createItem("flint_pickaxe","Flint Pickaxe\n§1PrimalCore§r",{name:"flint_pickaxe",meta:0},{stack:1});
Item.createItem("bone_sharp","Bone Sharp\n§1PrimalCore§r",{name:"bone_sharp",meta:0},{stack:1});
Item.createItem("bone_pickaxe","Bone Pickaxe\n§1PrimalCore§r",{name:"bone_pickaxe",meta:0},{stack:1});
ToolAPI.addToolMaterial("flint",{durability:50,level:1,efficiency:4,damage:2,enchantability:30});
ToolAPI.addToolMaterial("flint_hatchet",{durability:50,level:1,efficiency:5,damage:5,enchantability:30});
ToolAPI.addToolMaterial("bone",{durability:30,level:1,efficiency:4,damage:3,enchantability:30});
ToolLib.setTool(ItemID.flint_axe,"flint",ToolType.axe);
ToolLib.setTool(ItemID.flint_shovel,"flint",ToolType.shovel);
ToolLib.setTool(ItemID.flint_pickaxe,"flint",ToolType.pickaxe);
ToolLib.setTool(ItemID.flint_hatchet,"flint_hatchet",ToolType.axe);
ToolLib.setTool(ItemID.flint_hoe,"flint",ToolType.hoe);
ToolLib.setTool(ItemID.bone_sharp,"bone",ToolType.sword);
ToolLib.setTool(ItemID.bone_pickaxe,"bone",ToolType.pickaxe);
Item.addCreativeGroup("Flint_Tools","Flint Tools",[
ItemID.flint_hatchet,
ItemID.flint_axe,
ItemID.flint_pickaxe,
ItemID.flint_shovel,
ItemID.flint_hoe,
ItemID.flint_hand_saw
]);
Item.addCreativeGroup("Bone_Tools","Bone Tools",[
ItemID.bone_sharp,
ItemID.bone_pickaxe
]);