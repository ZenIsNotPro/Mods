Recipes.addFurnaceFuel(ItemID.oak_bark,0,200);
Recipes.addFurnace(ItemID.iron_ore_rock,0,452,0);
Recipes.addFurnace(ItemID.gold_ore_rock,0,371,0);
Recipes.addShaped(
{id:4,count:1,data:0},
["sss","scs","sss"],
['s',ItemID.rock_stone,0,'c',337,0]
);
Recipes.addShaped(
{id:ItemID.flint_pickaxe,count:1,data:0},
["fpf","fsf"," s "],
['f',ItemID.flint_flake,0,'p',ItemID.plant_cordage,0,'s',280,0]
);
Recipes.addShaped(
{id:ItemID.flint_axe,count:1,data:0},
["fpf","fs "," s "],
['f',ItemID.flint_flake,0,'p',ItemID.plant_cordage,0,'s',280,0]
);
Recipes.addShaped(
{id:ItemID.flint_shovel,count:1,data:0},
[" ff"," pf","s  "],
['f',ItemID.flint_flake,0,'p',ItemID.plant_cordage,0,'s',280,0]
);
Recipes.addShaped(
{id:ItemID.flint_hoe,count:1,data:0},
["ffp"," s ","s  "],
['f',ItemID.flint_flake,0,'p',ItemID.plant_cordage,0,'s',280,0]
);
Recipes.addShaped(
{id:ItemID.flint_hand_saw,count:1,data:0},
["f  "," fp"," ss"],
['f',ItemID.flint_flake,0,'p',ItemID.plant_cordage,0,'s',280,0]
);