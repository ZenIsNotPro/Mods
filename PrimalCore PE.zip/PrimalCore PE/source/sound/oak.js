var oakbark=new Sound("tool_scrape.ogg");
var name=new Sound("tool_woodsaw.ogg"); //no need to use