IDRegistry.genItemID("iron_ore_rock");
IDRegistry.genItemID("gold_ore_rock");
Item.createItem("iron_ore_rock","Iron Ore Rock\n§1PrimalCore§r",{name:"iron_ore_rock",meta:0},{stack:64});
Item.createItem("gold_ore_rock","Gold Ore Rock\n§1PrimalCore§r",{name:"gold_ore_rock",meta:0},{stack:64});