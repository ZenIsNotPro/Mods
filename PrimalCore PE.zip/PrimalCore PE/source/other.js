alert(" ");
Callback.addCallback("LevelLoaded",function(){
Game.message("§aPrimalCore PE§e was create by§b ZenNoName§r");
Game.message("§4Youtube§r:§1https://link1s.com/mlNn§r");
});
/*
 code by ZenNoName
 youtube:
 - name: ZenNoName
 - link: https://youtube.com/channel/UC9BzTDnVgMquCKFF6Iydr1A
*/